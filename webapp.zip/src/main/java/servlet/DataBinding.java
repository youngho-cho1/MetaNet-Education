package servlet;

public interface DataBinding {
	Object[] getDataBinders();
}
